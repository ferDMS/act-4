using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Estructura de una p�gina, con sus atributos (que son los de la DB)
public class Page
{
    public int Id;
    public int BookId;
    public int PageNum;
    public string Content;
}

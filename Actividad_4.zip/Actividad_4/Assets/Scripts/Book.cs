using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Estructura de un libro, con sus atributos (que son de la DB)
public class Book
{
    public int Id;
    public string Title;
    public string Author;
    public string Cover;
}
